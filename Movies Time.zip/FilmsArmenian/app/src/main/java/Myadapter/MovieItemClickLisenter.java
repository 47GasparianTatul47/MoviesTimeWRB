package Myadapter;

import android.widget.ImageView;

import models.Movie;

public interface MovieItemClickLisenter {


    void onMovieClick (Movie movie, ImageView movieImageView);

}

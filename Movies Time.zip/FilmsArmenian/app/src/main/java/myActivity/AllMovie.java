package myActivity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.SearchView;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.filmsarmenian.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import Myadapter.MovieAdapter;
import Myadapter.MovieItemClickLisenter;
import models.Movie;

public class AllMovie extends AppCompatActivity implements MovieItemClickLisenter {

    private RecyclerView recyclerView;
    private Toolbar toolbar;
    private Movie data;
    private MovieAdapter movieAdapterPopular;
    private List<Movie> allMovieList;
    private DatabaseReference getDatabaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_movie);



        toolbar = findViewById(R.id.toolbarALL);
        setSupportActionBar(toolbar);


        recyclerView = findViewById(R.id.RV_all_movies);

        allMovieList = new ArrayList<>();

        getDatabaseReference = FirebaseDatabase.getInstance().getReference("getAllMovie");

        getDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    data = ds.getValue(Movie.class);

                    allMovieList.add(data);
                }

                movieAdapterPopular = new MovieAdapter(allMovieList, AllMovie.this, AllMovie.this);
                recyclerView.setAdapter(movieAdapterPopular);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        recyclerView.setAnimation(AnimationUtils.loadAnimation(this, R.anim.scale_animation));
        recyclerView.setLayoutManager(new GridLayoutManager(this, 3));


    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onMovieClick(Movie movie, ImageView movieImageView) {
        Intent intent = new Intent(this, SeeMovie.class);

        intent.putExtra("title", movie.getName());
        intent.putExtra("imageURL", movie.getImgURL());
        intent.putExtra("imageCover", movie.getCovURL());
        intent.putExtra("movieUrl", movie.getMovieURL());
        intent.putExtra("description", movie.getDesc());
        intent.putExtra("rating", movie.getRating());
        intent.putExtra("actor", movie.getActor());
        intent.putExtra("country", movie.getCountry());
        intent.putExtra("year", movie.getYear());
        intent.putExtra("genre", movie.getGenre());

        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(AllMovie.this,
                movieImageView, "sharedName");

        startActivity(intent, options.toBundle());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);

        MenuItem menuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) menuItem.getActionView();


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {


                if (movieAdapterPopular != null) {
                    movieAdapterPopular.getFilter().filter(newText);

                }
                
                return false;
            }
        });

        return true;

    }
}

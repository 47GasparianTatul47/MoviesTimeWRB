package myActivity;

import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.bumptech.glide.Glide;
import com.example.filmsarmenian.R;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import Myadapter.MovieItemClickLisenter;
import models.Movie;

public class SeeMovie extends AppCompatActivity {

    private ImageView Movie_Image_URL, Movie_Cover_Image;
    private TextView Movie_Title, movie_description, movie_actor, movie_year,
            movie_country, movie_genre, not_found_movie;
    private PlayerView playerView;
    private ProgressBar progressBar;
    private FrameLayout frameLayout;
    private ImageView btn_fullScreen;
    private ScrollView sucsses_internet;
    private boolean flag = false;
    private RatingBar ratingBar;
    private SimpleExoPlayer simpleExoPlayer;
    private FrameLayout not_internet;
    public static String VIDEO_TEST_URL = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_movie);
        exoPlayer();
        initViews();
        getDataMain();

    }


    private void initViews() {
        movie_actor = findViewById(R.id.actor);
        movie_description = findViewById(R.id.description_movie);
        Movie_Image_URL = findViewById(R.id.seeMovieImage);
        Movie_Cover_Image = findViewById(R.id.detail_movie_cover);
        ratingBar = findViewById(R.id.rating);
        Movie_Title = findViewById(R.id.movie_nameSM);
        not_internet = findViewById(R.id.not_internet);
        sucsses_internet = findViewById(R.id.sucsses_internet);
        frameLayout = findViewById(R.id.relativeLayoutPL);
        playerView = findViewById(R.id.seeMovie_player);
        progressBar = findViewById(R.id.progress_bar);
        btn_fullScreen = playerView.findViewById(R.id.bt_fullScreen);
        movie_country = findViewById(R.id.movie_country);
        movie_year = findViewById(R.id.movie_year);
        movie_genre = findViewById(R.id.genere);
        not_found_movie = findViewById(R.id.not_found_film);


    }

    private void getDataMain() {

        initViews();

        String movieName = getIntent().getExtras().getString("title");
        String movie_Actor = getIntent().getExtras().getString("actor");
        String imageMovie = getIntent().getExtras().getString("imageURL");
        String imageCover = getIntent().getExtras().getString("imageCover");
        String movieYear = getIntent().getExtras().getString("year");
        String movieCountry = getIntent().getExtras().getString("country");
        String movieGenre = getIntent().getExtras().getString("genre");
        String movieDescription = getIntent().getExtras().getString("description");
        String movieRating = getIntent().getExtras().getString("rating");


        Glide.with(this).load(imageMovie).into(Movie_Image_URL);
        Glide.with(this).load(imageCover).into(Movie_Cover_Image);

        Picasso.with(this).load(imageMovie).into(Movie_Image_URL);



        movie_actor.setText(movie_Actor);
        movie_description.setText(movieDescription);
        Movie_Title.setText(movieName);
        ratingBar.setRating(Float.parseFloat(movieRating));
        movie_country.setText(movieCountry);
        movie_year.setText(movieYear);
        movie_genre.setText(movieGenre);

        Movie_Cover_Image.setAnimation(AnimationUtils.loadAnimation(this, R.anim.scale_animation));

    }

    private void exoPlayer() {

        initViews();


        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(this,
                Util.getUserAgent(this, "appaname"));

        String movieUrl = getIntent().getExtras().getString("movieUrl");


        VIDEO_TEST_URL = movieUrl;

        MediaSource videoSource = new ExtractorMediaSource.Factory(dataSourceFactory).
                createMediaSource(Uri.parse(VIDEO_TEST_URL));

        simpleExoPlayer = ExoPlayerFactory.newSimpleInstance(this);

        playerView.setPlayer(simpleExoPlayer);

        simpleExoPlayer.prepare(videoSource);

        simpleExoPlayer.setPlayWhenReady(true);


        simpleExoPlayer.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, @Nullable Object manifest, int reason) {

            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

            }

            @Override
            public void onLoadingChanged(boolean isLoading) {

            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

                if (playbackState == Player.STATE_BUFFERING) {
                    progressBar.setVisibility(View.VISIBLE);

                } else if (playbackState == Player.STATE_READY) {

                    progressBar.setVisibility(View.GONE);

                }

            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {

            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {

                not_found_movie.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);








            }

            @Override
            public void onPositionDiscontinuity(int reason) {

            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

            }

            @Override
            public void onSeekProcessed() {

            }

        });


        btn_fullScreen.setOnClickListener(v -> {

            if (flag) {
                btn_fullScreen.setImageDrawable(getResources().getDrawable(R.drawable.ic_fullscreen_black_24dp));
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);

                if (getSupportActionBar() != null) {
                    getSupportActionBar().show();
                }

                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) frameLayout.getLayoutParams();
                FrameLayout.LayoutParams paramsMovie = (FrameLayout.LayoutParams) playerView.getLayoutParams();


                params.width = params.MATCH_PARENT;
                params.height = params.WRAP_CONTENT;


                paramsMovie.width = params.MATCH_PARENT;
                paramsMovie.height = (int) getResources().getDimension(R.dimen.freame_height);


                playerView.setLayoutParams(paramsMovie);

                frameLayout.setLayoutParams(params);
                flag = false;

            } else {
                btn_fullScreen.setImageDrawable(getResources().getDrawable(R.drawable.exo_controls_fullscreen_exit));

                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

                if (getSupportActionBar() != null) {
                    getSupportActionBar().hide();
                }

                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);

                ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) frameLayout.getLayoutParams();
                FrameLayout.LayoutParams paramsMovie = (FrameLayout.LayoutParams) playerView.getLayoutParams();


                params.width = params.MATCH_PARENT;
                params.height = params.MATCH_PARENT;


                paramsMovie.width = (int) getResources().getDimension(R.dimen.widhtMovie);
                paramsMovie.height = (int) getResources().getDimension(R.dimen.height_Movie);

                playerView.setLayoutParams(paramsMovie);
                frameLayout.setLayoutParams(params);
                flag = true;
            }
        });

    }

    private void notFound() {

        if (VIDEO_TEST_URL == null) {

            not_found_movie.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        simpleExoPlayer.setPlayWhenReady(false);
        simpleExoPlayer.getPlaybackState();


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
        }

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) frameLayout.getLayoutParams();
        FrameLayout.LayoutParams paramsMovie = (FrameLayout.LayoutParams) playerView.getLayoutParams();


        params.width = params.MATCH_PARENT;
        params.height = params.WRAP_CONTENT;


        paramsMovie.width = params.MATCH_PARENT;
        paramsMovie.height = (int) getResources().getDimension(R.dimen.freame_height);


        playerView.setLayoutParams(paramsMovie);

        frameLayout.setLayoutParams(params);

    }
}
